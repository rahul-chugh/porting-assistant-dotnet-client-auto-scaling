﻿namespace eShopOnBlazor.Models;

public class CatalogType
{
    public int Id { get; set; }
    public string Type { get; set; }
}
